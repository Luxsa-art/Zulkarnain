package com.example.nainprak3

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        val fullName = intent.getStringExtra("FULL_NAME")
        val username = intent.getStringExtra("USERNAME")
        val age = intent.getStringExtra("AGE")
        val email = intent.getStringExtra("EMAIL")
        val gender = intent.getStringExtra("GENDER")

        val tvFullName = findViewById<TextView>(R.id.tv_full_name)
        val tvUsername = findViewById<TextView>(R.id.tv_username)
        val tvAge = findViewById<TextView>(R.id.tv_age)
        val tvEmail = findViewById<TextView>(R.id.tv_email)
        val tvGender = findViewById<TextView>(R.id.tv_gender)

        tvFullName.text = "Full Name: $fullName"
        tvUsername.text = "Username: $username"
        tvAge.text = "Age: $age"
        tvEmail.text = "Email: $email"
        tvGender.text = "Gender: $gender"
    }
}