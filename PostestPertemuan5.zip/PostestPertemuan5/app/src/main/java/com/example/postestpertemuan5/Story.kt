package com.example.postestpertemuan5

data class Story(
    val username: String,
    val profileImage: Int
)