package com.example.postestpertemuan5

import android.net.Uri

data class Post(
    var username: String,
    var caption: String,
    var imageUri: Uri?,
    val profileImage: Int
)