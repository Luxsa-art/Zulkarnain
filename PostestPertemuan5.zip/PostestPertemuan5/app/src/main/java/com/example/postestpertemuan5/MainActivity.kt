package com.example.postestpertemuan5

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var rvStories: RecyclerView
    private lateinit var rvPosts: RecyclerView
    private lateinit var fabAddPost: FloatingActionButton

    private lateinit var storyAdapter: StoryAdapter
    private lateinit var postAdapter: PostAdapter

    private val storyList = mutableListOf<Story>()
    private val postList = mutableListOf<Post>()

    private var selectedImageUri: Uri? = null
    private var ivPreview: ImageView? = null

    private val imagePickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let {
                selectedImageUri = it
                ivPreview?.setImageURI(selectedImageUri)
                ivPreview?.visibility = ImageView.VISIBLE
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvStories = findViewById(R.id.rv_stories)
        rvPosts = findViewById(R.id.rv_posts)
        fabAddPost = findViewById(R.id.fab_add_post)

        setupStoryRecyclerView()
        setupPostRecyclerView()

        fabAddPost.setOnClickListener {
            showPostDialog(null, -1)
        }

        populateDummyData()
    }

    private fun setupStoryRecyclerView() {
        storyAdapter = StoryAdapter(storyList)
        rvStories.adapter = storyAdapter
    }

    private fun setupPostRecyclerView() {
        postAdapter = PostAdapter(postList) { post, position ->
            showPostOptions(post, position)
        }
        rvPosts.adapter = postAdapter
    }

    private fun showPostOptions(post: Post, position: Int) {
        val view = rvPosts.findViewHolderForAdapterPosition(position)?.itemView?.findViewById<ImageView>(R.id.iv_post_options)
        view?.let {
            val popup = PopupMenu(this, it)
            popup.menuInflater.inflate(R.menu.post_options_menu, popup.menu)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.menu_edit -> {
                        showPostDialog(post, position)
                        true
                    }
                    R.id.menu_delete -> {
                        postList.removeAt(position)
                        postAdapter.notifyItemRemoved(position)
                        Toast.makeText(this, "Hapus ${post.username}", Toast.LENGTH_SHORT).show()
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }
    }


    private fun showPostDialog(post: Post?, position: Int) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_post, null)
        val etUsername = dialogView.findViewById<EditText>(R.id.et_username)
        val etCaption = dialogView.findViewById<EditText>(R.id.et_caption)
        val btnAddImage = dialogView.findViewById<Button>(R.id.btn_add_image)
        ivPreview = dialogView.findViewById(R.id.iv_preview)
        val btnSave = dialogView.findViewById<Button>(R.id.btn_save)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        post?.let {
            etUsername.setText(it.username)
            etCaption.setText(it.caption)
            selectedImageUri = it.imageUri
            ivPreview?.setImageURI(selectedImageUri)
            ivPreview?.visibility = if (selectedImageUri != null) ImageView.VISIBLE else ImageView.GONE
        }

        btnAddImage.setOnClickListener {
            Intent(Intent.ACTION_PICK).also {
                it.type = "image/*"
                imagePickerLauncher.launch(it)
            }
        }

        btnSave.setOnClickListener {
            val username = etUsername.text.toString()
            val caption = etCaption.text.toString()

            if (username.isNotEmpty() && caption.isNotEmpty() && selectedImageUri != null) {
                if (post != null && position != -1) {
                    post.username = username
                    post.caption = caption
                    post.imageUri = selectedImageUri
                    postAdapter.notifyItemChanged(position)
                    Toast.makeText(this, "Post diperbarui", Toast.LENGTH_SHORT).show()
                } else {
                    val newPost = Post(username, caption, selectedImageUri, R.drawable.avatar1)
                    postList.add(0, newPost)
                    postAdapter.notifyItemInserted(0)
                }
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Isi semua kolom dulu", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun populateDummyData() {
        storyList.clear()
        storyList.add(Story("intan_dwi", R.drawable.avatar1))
        storyList.add(Story("minda_04", R.drawable.avatar2))
        storyList.add(Story("rubi_community", R.drawable.avatar3))
        storyList.add(Story("rizka", R.drawable.avatar4))
        storyList.add(Story("amelia", R.drawable.avatar5))
        storyList.add(Story("yorsyd", R.drawable.avatar6))
        storyAdapter.notifyDataSetChanged()

        postList.clear()
        val postImageUri = Uri.parse("android.resource://" + packageName + "/" + R.drawable.post_running)
        val postImageUri2 = Uri.parse("android.resource://" + packageName + "/" + R.drawable.post_running1)
        postList.add(Post("intan_dwi", "Dapat ikan nich, masa kamu enggak wkwkwkwkw", postImageUri, R.drawable.avatar1))
        postList.add(Post("minda_04", "Hari yang menyenangkan! ✨", postImageUri, R.drawable.avatar2))
        postList.add(Post("rubi_community", "Edukasi anak SD 💚", postImageUri2, R.drawable.avatar3))
        postAdapter.notifyDataSetChanged()
    }
}