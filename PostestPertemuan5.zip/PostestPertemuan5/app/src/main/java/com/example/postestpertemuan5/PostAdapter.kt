package com.example.postestpertemuan5

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostAdapter(
    private val postList: MutableList<Post>,
    private val onPostOptionsClicked: (Post, Int) -> Unit
) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = postList[position]
        holder.ivPostProfile.setImageResource(post.profileImage)
        holder.tvPostUsername.text = post.username
        holder.ivPostImage.setImageURI(post.imageUri)
        holder.tvPostCaption.text = post.caption

        holder.ivPostOptions.setOnClickListener {
            onPostOptionsClicked(post, position)
        }
    }

    override fun getItemCount(): Int = postList.size

    inner class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivPostProfile: ImageView = itemView.findViewById(R.id.iv_post_profile)
        val tvPostUsername: TextView = itemView.findViewById(R.id.tv_post_username)
        val ivPostImage: ImageView = itemView.findViewById(R.id.iv_post_image)
        val tvPostCaption: TextView = itemView.findViewById(R.id.tv_post_caption)
        val ivPostOptions: ImageView = itemView.findViewById(R.id.iv_post_options)
    }
}