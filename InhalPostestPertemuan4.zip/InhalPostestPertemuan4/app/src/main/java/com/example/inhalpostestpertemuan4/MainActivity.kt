package com.example.inhalpostestpertemuan4

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var editTextNama: EditText
    private lateinit var editTextNIK: EditText
    private lateinit var editTextKabupaten: EditText
    private lateinit var editTextKecamatan: EditText
    private lateinit var editTextDesa: EditText
    private lateinit var editTextRT: EditText
    private lateinit var editTextRW: EditText
    private lateinit var radioGroupJenisKelamin: RadioGroup
    private lateinit var spinnerStatus: Spinner
    private lateinit var buttonSimpan: Button
    private lateinit var buttonReset: Button
    private lateinit var textViewHasil: TextView

    private val daftarWarga = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        editTextNama = findViewById(R.id.editTextNama)
        editTextNIK = findViewById(R.id.editTextNIK)
        editTextKabupaten = findViewById(R.id.editTextKabupaten)
        editTextKecamatan = findViewById(R.id.editTextKecamatan)
        editTextDesa = findViewById(R.id.editTextDesa)
        editTextRT = findViewById(R.id.editTextRT)
        editTextRW = findViewById(R.id.editTextRW)
        radioGroupJenisKelamin = findViewById(R.id.radioGroupJenisKelamin)
        spinnerStatus = findViewById(R.id.spinnerStatus)
        buttonSimpan = findViewById(R.id.buttonSimpan)
        buttonReset = findViewById(R.id.buttonReset)
        textViewHasil = findViewById(R.id.textViewHasil)

        // Setup Spinner
        val statusPernikahan = arrayOf("Belum Menikah", "Menikah", "Cerai")
        val statusAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, statusPernikahan)
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerStatus.adapter = statusAdapter

        buttonSimpan.setOnClickListener {
            simpanData()
        }

        buttonReset.setOnClickListener {
            resetData()
        }
    }

    private fun simpanData() {
        val nama = editTextNama.text.toString().trim()
        val nik = editTextNIK.text.toString().trim()
        val kabupaten = editTextKabupaten.text.toString().trim()
        val kecamatan = editTextKecamatan.text.toString().trim()
        val desa = editTextDesa.text.toString().trim()
        val rt = editTextRT.text.toString().trim()
        val rw = editTextRW.text.toString().trim()

        if (nama.isEmpty() || nik.isEmpty() || kabupaten.isEmpty() || kecamatan.isEmpty() || desa.isEmpty() || rt.isEmpty() || rw.isEmpty()) {
            Toast.makeText(this, "Semua data harus diisi!", Toast.LENGTH_SHORT).show()
            return
        }

        val selectedJenisKelaminId = radioGroupJenisKelamin.checkedRadioButtonId
        if (selectedJenisKelaminId == -1) {
            Toast.makeText(this, "Pilih jenis kelamin!", Toast.LENGTH_SHORT).show()
            return
        }
        val radioButtonJenisKelamin = findViewById<RadioButton>(selectedJenisKelaminId)
        val jenisKelamin = radioButtonJenisKelamin.text.toString()

        val status = spinnerStatus.selectedItem.toString()

        val dataWarga =
            "${daftarWarga.size + 1}. $nama ($jenisKelamin) - $status\nNIK: $nik\nAlamat: RT $rt/RW $rw, $desa, $kecamatan, $kabupaten"
        daftarWarga.add(dataWarga)

        updateHasil()
        clearForm()
        Toast.makeText(this, "Data berhasil disimpan!", Toast.LENGTH_SHORT).show()
    }

    private fun resetData() {
        daftarWarga.clear()
        updateHasil()
        clearForm()
        Toast.makeText(this, "Semua data berhasil dihapus!", Toast.LENGTH_SHORT).show()
    }

    private fun updateHasil() {
        if (daftarWarga.isEmpty()) {
            textViewHasil.text = "Belum ada data warga yang tersimpan."
        } else {
            textViewHasil.text = daftarWarga.joinToString("\n\n")
        }
    }

    private fun clearForm() {
        editTextNama.text.clear()
        editTextNIK.text.clear()
        editTextKabupaten.text.clear()
        editTextKecamatan.text.clear()
        editTextDesa.text.clear()
        editTextRT.text.clear()
        editTextRW.text.clear()
        radioGroupJenisKelamin.clearCheck()
        spinnerStatus.setSelection(0)
    }
}
